#include<iostream>
using namespace std;

int main()
{
    int i;
    float f;
    cout<<"Size of int = "<<sizeof(i);
    cout<<"\nSize of int = "<<sizeof(int);
    cout<<"\nSize of float = "<<sizeof(f);
    cout<<"\nSize of float = "<<sizeof(float);
    cout<<"\nSize of char = "<<sizeof(char);

return 0;
}
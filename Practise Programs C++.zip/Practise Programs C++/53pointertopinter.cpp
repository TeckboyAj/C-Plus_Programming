#include<iostream>
using namespace std;

int main()
{
    int i=3, *j, **k;
    j = &i;
    k = &j;
    cout<<"Value of i = "<<i;
    cout<<"\nValue of j = "<<*j;
    cout<<"\nValue of k = "<<**k;
    cout<<"\nAddress of i = "<<&i;
    cout<<"\nValue of i through j pointer = "<<j;
    cout<<"\nAddress of j = "<<&j;
    cout<<"\nAddress of j through k pointer= "<<k;
    cout<<"\nAddress of k = "<<&k;

return 0;
}
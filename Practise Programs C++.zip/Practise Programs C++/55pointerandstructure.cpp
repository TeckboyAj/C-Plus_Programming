#include<iostream>
using namespace std;

struct date{
    int dd;
    int mm;
    int yy;
};

int main()
{
    struct date d, *p=&d;
    cout<<"Enter date : ";
    cin>>p->dd>>p->mm>>p->yy;
    cout<<"Output :\n";
    cout<<p->dd<<"/"<<p->mm<<"/"<<p->yy;  

return 0;
}
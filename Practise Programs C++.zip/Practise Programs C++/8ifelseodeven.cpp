#include<iostream>
using namespace std;

int main()
{
    int num;
    cout<<"Enter the number = ";
    cin>>num;
    if(num%2==0)
    {
        cout<<"Numbr is even"<<endl;
    }else{
        cout<<"Number is odd";
    }
    
return 0;
}
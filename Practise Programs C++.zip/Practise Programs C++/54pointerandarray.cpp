#include<iostream>
using namespace std;

int main()
{
    int a[20];
    int *ptr,n,sum=0;
    cout<<"Enter number of elements = "<<endl;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cout<<"Enter a["<<i<<"] = "<<endl;
        cin>>a[i];
    }
    ptr = a;
    for(int i=0;i<n;i++)
    {
        sum+=*(ptr+i);
    }
    cout<<"\nSum ="<<sum;

return 0;
}
#include<iostream>
using namespace std;

int main()
{
    char name[20];
    cout<<"Enter your name : "<<endl;
    cin.get(name,20);
    cout<<"Your name is "<<name;

return 0;
}
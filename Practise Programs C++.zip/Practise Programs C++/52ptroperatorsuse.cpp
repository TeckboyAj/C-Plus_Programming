#include<iostream>
using namespace std;

int main()
{
    int i = 5, *ptr;
    ptr = &i; //addressof Operator
    cout<<"Value of i = "<<i;
    cout<<"Value pointed by pointer ptr = "<<*ptr; //indirection or defreference operator or astrick sign
    *ptr = 10;
    cout<<"Value of i = "<<i;
    int j = *ptr;
    cout<<"Vale of j = "<<j;

return 0;
}
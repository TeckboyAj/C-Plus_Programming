#include<iostream>
using namespace std;

int main()
{
    char ch='x';
    cout.put(ch);
    cout.put('\n');
    cout.put('A');
    cout.put('\n');
    cout.put('b');
    cout.write("\n",1);
    cout.write("Hello Friends how are you",13);
    cout.write("\n",1);
    cout.write("Bye",3);
return 0;
}
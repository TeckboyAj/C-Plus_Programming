#include<iostream>
using namespace std;
int main()
{ 
    int a,b,sum; //variables
    cout<<"Enter Number a =\t"; //\t for space
    cin>>a;                                                
    cout<<"Enter Number b =\t";
    cin>>b;
    sum = a+b; // + operator is used
    cout<<"Sum = "<<sum;
    return 0;

}
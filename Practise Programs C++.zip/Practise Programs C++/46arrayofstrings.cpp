#include<iostream>
using namespace std;

int main()
{
    char day[7][10]={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
    for(int i=0;i<7;i++)
    {
        cout<<day[i]<<"\n";
    }

return 0;
}